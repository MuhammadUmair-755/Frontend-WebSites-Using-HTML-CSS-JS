// ============== Scrol Up ===================

$("#scroll-up").on("click",function(e){
    e.preventDefault();
  $("html,body").animate({ scrollTop: 0 });
})

// ================== Modal ======================
 
 $('.modal-trigger').on("click", function () {
  const imageSrc = $(this).attr('src');
  $('#modal-image').attr('src', imageSrc);
  $('#staticBackdrop').modal('show');
});
