// ================ Home Page Couresel ===================

 document.addEventListener("DOMContentLoaded", function () {
    const row = document.querySelector(".img-overlay .row");
    const slideSpeed = 100;
    const delay = 4000;

    row.style.display = "flex";
    row.style.transition = `transform ${slideSpeed}ms ease`;

    window.slideleft = () => {
      const colWidth = row.children[0].offsetWidth;

      const clone = row.children[0].cloneNode(true);
      row.appendChild(clone);

      row.style.transition = `transform ${slideSpeed}ms ease`;
      row.style.transform = `translateX(-${colWidth}px)`;

    
      setTimeout(() => {
        row.style.transition = "none";
        row.style.transform = "translateX(0)";

        // 4. Remove the original first .col
        row.removeChild(row.children[0]);

        // 5. Force reflow to reset transition
        void row.offsetWidth;
      }, slideSpeed);
    };4
    setInterval(slideleft, delay);
  });
// ================= Home Slide Number 2 Closed-Sldier ===================
document.addEventListener("DOMContentLoaded", () => {
    const sliderRow = document.querySelector(".closed-slider_row");
    const items = document.querySelectorAll(".closed-slider_row .col");
    const itemCount = items.length;
    const itemWidth = items[0].offsetWidth + 30; // include 30px gap
    let index = 0;

    // Clone all items to create an infinite loop effect
    items.forEach(item => {
      const clone = item.cloneNode(true);
      sliderRow.appendChild(clone);
    });

    setInterval(() => {
      index++;

      // Slide to next
      sliderRow.style.transform = `translateX(-${index * itemWidth}px)`;

      // Reset after full set is shown (before clones)
      if (index >= itemCount) {
        setTimeout(() => {
          sliderRow.style.transition = "none"; // disable transition to reset
          sliderRow.style.transform = `translateX(0px)`;
          index = 0;

          // Re-enable transition
          setTimeout(() => {
            sliderRow.style.transition = "transform 0.5s ease-in-out";
          }, 50);
        }, 500); // wait till current slide ends
      }
    }, 4000);
  });
  // ======================= Category page slider ==============

const track = document.querySelector('.slider-track');
const dots = document.querySelectorAll('.dot');
let current = 0;

function currentSlide(n) {
  current = n;
  updateSlider();
}

function updateSlider() {
  track.style.transform = `translateX(-${current * 100}%)`;
  dots.forEach(dot => dot.classList.remove('active'));
  dots[current].classList.add('active');
}


// =============== Deadline ===============
const deadline = new Date("2025-12-31T23:59:59").getTime(); //setting deadline
  function updateCountdown() {
    const now = new Date().getTime();
    const distance = deadline - now;

    if (distance < 0) {
      document.querySelector(".counter").innerHTML = "🎉 Deadline Passed!";
      clearInterval(timer);
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.querySelector(".days .value").textContent = days;
    document.querySelector(".hours .value").textContent = hours;
    document.querySelector(".minutes .value").textContent = minutes;
    document.querySelector(".seconds .value").textContent = seconds;
  }

  // Initial call
  updateCountdown();

  // Call every second
  const timer = setInterval(updateCountdown, 1000);