
$(window).on("scroll", function () {
  const header = $("#mainHeader");
  if ($(this).scrollTop() > 0) {
    header.addClass("shadow-sm");
  } else {
    header.removeClass("shadow-sm");
  }
});
// =============== top-scroll=====================

$(".up-btn").on("click", function (e) {
  e.preventDefault();
  $("html,body").animate({ scrollTop: 0 });
});
// ================= client slider==================

$(document).ready(function () {
  const logoRow = $("#logoRow");
  if (!logoRow.data("cloned")) {
    logoRow.html(logoRow.html()+logoRow.html());
    logoRow.data("cloned", true);
  }
  const items = logoRow.find(".flex-item");
  let currentIndex = 0;
  let itemWidth = items.first().outerWidth();
  const totalItems = items.length / 2;

  $(window).on("resize", function () {
    itemWidth = items.first().outerWidth();
  });

  setInterval(() => {
    currentIndex++;
    logoRow.css({
      transition: "transform 0.5s ease",
      transform: `translateX(-${currentIndex * itemWidth}px)`
    });

    if (currentIndex >= totalItems) {
      setTimeout(() => {
        logoRow.css({
          transition: "none",
          transform: `translateX(0px)`
        });
        currentIndex = 0;
      }, 500);
    }
  }, 4000);
});

// ======================== Service ===========================

new Swiper(".card-wrapper", {
  spaceBetween: 30,
  loop: true,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },

  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    dynamicBullets: false,
  },
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 1,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});

// =================== Modal Img ===================

$(document).ready(function () {
  const modal = $(".filter-modal");
  const modalImg = $(".modalimg");
  //list of images
  $(".myImg").on("click", function () {
    modal.css("display", "block");
    modalImg.attr("src", $(this).attr("src"));
  });
  $(".close-modal").on("click", function () {
    modal.css("display", "none");
  });
});

// ==========filter portfolio===============

$(".filter-btns button").on("click",function(){
  $(".filter-btns .active").removeClass("active");
  $(this).addClass("active");
  const filterval=$(this).data("name");
  $(".filterable-cards .card").each(function(){
   
    if( filterval === $(this).data("name") ||
     filterval=== "all"){
      $(this).parent().removeClass("d-none");
    }
    else
      $(this).parent().addClass("d-none");
  })
  AOS.refresh();
});
// ==================== nav links==============================

$(".navbar-link[href]").on("click", function (e) {
  const href = $(this).attr("href");
  if (href.startsWith("#")) {
    const target = $(href);
    if (target) {
      e.preventDefault();      
      const modalInstance = $("#menuModal");
      modalInstance.hide();
      setTimeout(() => {
        target[0].scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  } else if (href === "Blog-Details.html") {
    const modalInstance = $("#menuModal");
    modalInstance.hide();
    setTimeout(() => {
      window.location.href = "Blog-Details.html";
    }, 300);
  }
});
