// window.addEventListener("scroll", function () {
//   const header = document.getElementById("mainHeader");
//   if (window.scrollY > 0) {
//     header.classList.add("shadow-sm");
//   } else {
//     header.classList.remove("shadow-sm");
//   }
// });




// document.querySelector(".up-btn").addEventListener("click", function (event) {
//   event.preventDefault();
//   window.scrollTo({
//     top: 0,
//     behavior: "smooth",
//   });
// });



// document.addEventListener("DOMContentLoaded", function () {
//   const logoRow = document.getElementById("logoRow");

//   if (!logoRow.dataset.cloned) {
//     logoRow.innerHTML += logoRow.innerHTML;
//     logoRow.dataset.cloned = "true";
//   }
//   const items = logoRow.querySelectorAll(".flex-item");
//   let currentIndex = 0;
//   let itemWidth = items[0].offsetWidth;
//   const totalItems = items.length / 2;

//   window.addEventListener("resize", () => {
//     itemWidth = items[0].offsetWidth;
//   });

//   setInterval(() => {
//     currentIndex++;
//     logoRow.style.transition = "transform 0.5s ease";
//     logoRow.style.transform = `translateX(-${currentIndex * itemWidth}px)`;

//     if (currentIndex >= totalItems) {
//       setTimeout(() => {
//         logoRow.style.transition = "none";
//         logoRow.style.transform = `translateX(0px)`;
//         currentIndex = 0;
//       }, 500);
//     }
//   }, 4000);
// });




// var images = document.querySelectorAll(".myImg");
// var modal = document.querySelector(".filter-modal");
// var modalImg = document.querySelector(".modalimg");

// images.forEach(function (img) {
//   img.onclick = function () {
//     modal.style.display = "block";
//     modalImg.src = this.src;
//   };
// });

// var span = document.querySelector(".close-modal");
// span.onclick = function () {
//   modal.style.display = "none";
// };






// const filterButtons = document.querySelectorAll(".filter-btns button");
// const filterableCards = document.querySelectorAll(".filterable-cards .card");
// const filterCards = (e) => {
//   document.querySelector(".active").classList.remove("active");
//   e.target.classList.add("active");

//   filterableCards.forEach((card) => {
//     card.classList.add("hide");
//     if (
//       card.dataset.name === e.target.dataset.name ||
//       e.target.dataset.name === "all"
//     ) {
//       card.classList.remove("hide");
//     }
//   });
// };
// filterButtons.forEach((button) =>
//   button.addEventListener("click", filterCards)
// );



// document.querySelectorAll(".navbar-link[href]").forEach((link) => {
//   link.addEventListener("click", function (e) {
//     const href = this.getAttribute("href");
//     if (href.startsWith("#")) {
//       const target = document.querySelector(href);

//       if (target) {
//         e.preventDefault();
//         const modal = bootstrap.Modal.getInstance(
//           document.getElementById("menuModal")
//         );
//         modal.hide(); //modal fix hai usko close kia
//         setTimeout(() => {
//           target.scrollIntoView({ behavior: "smooth" });
//         }, 300); //wait for the modal then scroll
//       }
//     } else if (href === "Blog-Details.html") {
//       const modal = bootstrap.Modal.getInstance(
//         document.getElementById("menuModal")
//       );
//       modal.hide();
//       setTimeout(() => {
//         window.location.href = "Blog-Details.html";
//       }, 300);
//     }
//   });
// });





// const pagelinks = document.querySelectorAll("ul.pagination .page-link a");
// const pageClicking = (e) => {
//   e.preventDefault();
//   document.querySelector("ul.pagination a.active").classList.remove("active");
//   e.target.classList.add("active");
// };
// pagelinks.forEach((link) => {
//   link.addEventListener("click", pageClicking);
// });

